from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List
import uuid, json, os, time

STORE = os.path.join(os.path.dirname(__file__), "instances.json")
if not os.path.exists(STORE):
    with open(STORE, "w") as f:
        json.dump([], f)

app = FastAPI(title="VPS Manager - Prototype")

class CreateVPSRequest(BaseModel):
    name: str
    image: Optional[str] = "ubuntu-22.04"
    cpus: Optional[int] = 1
    memory_mb: Optional[int] = 512

class Instance(BaseModel):
    id: str
    name: str
    image: str
    cpus: int
    memory_mb: int
    status: str
    created_at: float

def read_store():
    with open(STORE, "r") as f:
        return json.load(f)

def write_store(data):
    with open(STORE, "w") as f:
        json.dump(data, f, indent=2)

@app.post("/create_vps/", response_model=Instance)
def create_vps(req: CreateVPSRequest):
    inst = {
        "id": str(uuid.uuid4()),
        "name": req.name,
        "image": req.image,
        "cpus": req.cpus,
        "memory_mb": req.memory_mb,
        "status": "running",
        "created_at": time.time()
    }
    data = read_store()
    data.append(inst)
    write_store(data)
    return inst

@app.get("/list_vps/", response_model=List[Instance])
def list_vps():
    return read_store()

@app.post("/control/{instance_id}")
def control(instance_id: str, action: str):
    data = read_store()
    for inst in data:
        if inst["id"] == instance_id:
            if action not in ("start","stop","reboot","delete"):
                raise HTTPException(status_code=400, detail="action must be start/stop/reboot/delete")
            if action == "delete":
                data.remove(inst)
                write_store(data)
                return {"result":"deleted"}
            if action == "stop":
                inst["status"] = "stopped"
            elif action == "start":
                inst["status"] = "running"
            elif action == "reboot":
                inst["status"] = "rebooting"
            write_store(data)
            return {"result":"ok","status":inst["status"]}
    raise HTTPException(status_code=404, detail="instance not found")

@app.get("/health")
def health():
    return {"status":"ok"}
