# VPS Hosting Manager - Minimal Prototype

This is a minimal, local prototype of a VPS hosting manager.
It does NOT create real VMs — instead it simulates VPS creation using a local JSON store.
You can use it as a starting scaffold to integrate with real backends like LXD, Proxmox, or libvirt.

## What's included
- `backend/` - FastAPI backend with endpoints to create/list/control simulated VPS instances.
- `frontend/` - Simple single-page HTML + JS that interacts with the backend.
- `start.sh` - Convenience script to create a virtualenv and run the backend.

## Requirements
- Python 3.10+ (tested with 3.11)
- `pip` to install requirements

## Run backend (quick)
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```
Then open `frontend/index.html` in your browser (or serve it).

## How to extend
- Replace the mock implementation in `backend/app.py` with actual calls to LXD/Proxmox APIs.
- Add authentication, persistent DB (Postgres), and a task queue for long-running operations.