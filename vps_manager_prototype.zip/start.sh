#!/usr/bin/env bash
set -e
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
echo
echo "Run: uvicorn app:app --reload --host 0.0.0.0 --port 8000"
