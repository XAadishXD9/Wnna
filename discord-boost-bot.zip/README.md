# Discord Boost Bot (Node.js)

A simple Discord bot that detects and logs legitimate server boosts, assigns a Booster role, announces boosts, and keeps a leaderboard.

## Requirements
- Node.js 18+ (recommended)
- A Discord application + bot token (create in Discord Developer Portal)

## Setup
1. Copy `.env.example` to `.env` and fill in your `BOT_TOKEN` and `GUILD_ID`.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Run the bot:
   ```bash
   node index.js
   ```
