import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function initDB(dbFile) {
  const dbPath = path.isAbsolute(dbFile) ? dbFile : path.join(__dirname, dbFile);
  const exists = fs.existsSync(dbPath);
  const db = new Database(dbPath);

  if (!exists) {
    db.exec(`
      CREATE TABLE boosts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_tag TEXT NOT NULL,
        boosted_at TEXT NOT NULL
      );
      CREATE TABLE boost_counts (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        count INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, user_id)
      );
    `);
  }

  const insertBoost = db.prepare(
    'INSERT INTO boosts (guild_id, user_id, user_tag, boosted_at) VALUES (?, ?, ?, ?)'
  );
  const incCount = db.prepare(
    `INSERT INTO boost_counts (guild_id,user_id,count) VALUES (?, ?, 1)
     ON CONFLICT(guild_id,user_id) DO UPDATE SET count = count + 1;`
  );
  const topBoosters = db.prepare(
    'SELECT user_id, user_tag, count FROM boost_counts WHERE guild_id = ? ORDER BY count DESC LIMIT ?'
  );

  return { db, insertBoost, incCount, topBoosters };
}
