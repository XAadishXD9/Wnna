import 'dotenv/config';
import { Client, GatewayIntentBits, Events, Partials } from 'discord.js';
import { initDB } from './db.js';
import path from 'path';

const TOKEN = process.env.BOT_TOKEN;
const LOG_CHANNEL_NAME = process.env.LOG_CHANNEL_NAME || 'boost-log';
const BOOSTER_ROLE_NAME = process.env.BOOSTER_ROLE_NAME || 'Booster';
const DB_FILE = process.env.DATABASE_FILE || './boosts.sqlite';

if (!TOKEN) {
  console.error('ERROR: BOT_TOKEN environment variable is required');
  process.exit(1);
}

const { insertBoost, incCount, topBoosters } = initDB(DB_FILE);

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
  partials: [Partials.GuildMember]
});

client.once(Events.ClientReady, () => {
  console.log(`Logged in as ${client.user.tag}`);
});

async function getOrCreateRole(guild) {
  let role = guild.roles.cache.find(r => r.name === BOOSTER_ROLE_NAME);
  if (!role) {
    try {
      role = await guild.roles.create({
        name: BOOSTER_ROLE_NAME,
        reason: 'Create booster role for boost tracking',
        permissions: []
      });
    } catch (err) {
      console.warn('Could not create role:', err.message);
    }
  }
  return role;
}

client.on(Events.GuildMemberUpdate, async (oldMember, newMember) => {
  try {
    const oldBoost = oldMember?.premiumSince;
    const newBoost = newMember?.premiumSince;

    if (!oldBoost && newBoost) {
      const guild = newMember.guild;
      const when = newBoost.toISOString();
      const userTag = `${newMember.user.username}#${newMember.user.discriminator}`;

      const role = await getOrCreateRole(guild);
      if (role && !newMember.roles.cache.has(role.id)) {
        try { await newMember.roles.add(role, 'User boosted the server'); } catch (err) { console.warn('Failed to add role:', err.message); }
      }

      const logChannel = guild.channels.cache.find(c => c.name === LOG_CHANNEL_NAME && c.isTextBased());
      if (logChannel) {
        logChannel.send({ content: `🎉 **${userTag}** started boosting the server — ${when}` }).catch(() => {});
      }

      insertBoost.run(guild.id, newMember.id, userTag, when);
      incCount.run(guild.id, newMember.id);
      console.log('Logged boost:', guild.id, newMember.id, when);
    }
  } catch (err) {
    console.error('Error handling GuildMemberUpdate:', err);
  }
});

client.on(Events.ClientReady, async () => {
  try {
    const data = [{ name: 'boosters', description: 'Show top boosters for this server' }];
    for (const guild of client.guilds.cache.values()) {
      await guild.commands.set(data);
    }
    console.log('Slash commands registered.');
  } catch (err) {
    console.warn('Could not register slash commands:', err.message);
  }
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isCommand()) return;
  if (interaction.commandName === 'boosters') {
    await interaction.deferReply();
    try {
      const rows = topBoosters.all(interaction.guildId, 10);
      if (!rows || rows.length === 0) return interaction.editReply('No boosters recorded yet.');
      const lines = rows.map((r, i) => `${i + 1}. **${r.user_tag}** — ${r.count}`);
      await interaction.editReply(lines.join('\n'));
    } catch (err) {
      console.error('Error in boosters command:', err);
      interaction.editReply('Error fetching leaderboard.');
    }
  }
});

client.login(TOKEN);
